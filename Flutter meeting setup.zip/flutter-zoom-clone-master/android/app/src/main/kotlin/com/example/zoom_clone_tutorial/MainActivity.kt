package com.example.zoom_clone_tutorial

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
